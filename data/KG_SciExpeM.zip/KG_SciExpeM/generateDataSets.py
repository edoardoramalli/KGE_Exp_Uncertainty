from pykeen.triples import TriplesFactory
import os
import glob



def split_and_generate_dataset(path_scenario):
    tsv_file = glob.glob(os.path.join(path_scenario, 'Dataset', '*.tsv'))
    if len(tsv_file) > 1 or len(tsv_file) == 0:
        raise ValueError('Missing File or multiple')
    else:
        tsv_file = tsv_file[0]

    tf = TriplesFactory.from_path(tsv_file)

    training, testing, validation = tf.split([.8, .1, .1])

    training.to_path_binary(path=os.path.join(path_scenario, 'Dataset', 'training'))
    testing.to_path_binary(path=os.path.join(path_scenario, 'Dataset', 'testing'))
    validation.to_path_binary(path=os.path.join(path_scenario, 'Dataset', 'validation'))