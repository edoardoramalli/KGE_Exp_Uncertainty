from Toy.BaseClasses import Experiment
import random
import os
import pandas as pd
from CaseC import C_Experiment

# Aggiungiamo alla media correlazione il similar


scenario = 'CaseD'

general_path = '../Scenario/{}/Dataset/'.format(scenario)

os.makedirs(general_path, exist_ok=True)

csv = []

exps = []

list_of_records = []

for i in range(1000):
    t = C_Experiment(i)
    exps.append(t)


for e in exps:
    c_u = e.uncertainty
    for ee in exps:
        # Now stesso autore quindi incertazza gia nelle possibili incertezze
        if e.similar(ee) and e != ee:
            e.close.add(ee.exp_id)

    list_of_records.append(e.to_record())
    csv += e.to_kg()

df = pd.DataFrame(list_of_records)

df.to_csv(os.path.join(general_path, '{}_df.csv'.format(scenario)), index=False)

with open(os.path.join(general_path, '{}.tsv'.format(scenario)), 'w+') as f:
    for i in csv:
        f.write(i + '\n')