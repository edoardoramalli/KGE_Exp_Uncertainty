from Toy.BaseClasses import Experiment
import random
import os
import pandas as pd
import networkx as nx


# Aggiungiamo alla forte correlazione il similar

class C_Experiment(Experiment):
    authors_activity = {}
    possible_uncertainty_author = {}
    possible_uncertainty_author_year = {}
    possible_uncertainty_author_year_exp_type = {}
    possible_uncertainty_author_year_exp_type_target = {}

    for i in range(Experiment.n_possible_author):
        c_author = f'Author {i}'
        authors_activity[c_author] = random.choice(Experiment.possible_year_of_activity)

        # index = list_uncertainties.index(random.choice(list_uncertainties))
        #
        # possible = list_uncertainties[max(0, index - 1): min(len(list_uncertainties), index + 2)]
        #
        possible_uncertainty_author[c_author] = random.choice(Experiment.list_uncertainties)

    def pick_uncertainty(self):
        return C_Experiment.possible_uncertainty_author[self.author]


scenario = 'CaseD_Bis'

general_path = '../Scenario/{}/Dataset/'.format(scenario)

os.makedirs(general_path, exist_ok=True)

csv = []

exps = []

list_of_records = []

for i in range(1000):
    t = C_Experiment(i)
    exps.append(t)

G = nx.Graph()
G.add_nodes_from([c.exp_id for c in exps])

for e in exps:
    c_u = e.uncertainty
    for ee in exps:
        # Now stesso autore quindi incertazza gia nelle possibili incertezze
        if e.similar(ee) and e != ee:
            e.close.add(ee.exp_id)
            edge = (e.exp_id, ee.exp_id)
            G.add_edge(*edge)

    # print(len(e.close), e.exp_id, e.close)
    list_of_records.append(e.to_record())
    csv += e.to_kg()


df = pd.DataFrame(list_of_records)

df.to_csv(os.path.join(general_path, '{}_df.csv'.format(scenario)), index=False)

with open(os.path.join(general_path, '{}.tsv'.format(scenario)), 'w+') as f:
    for i in csv:
        f.write(i + '\n')