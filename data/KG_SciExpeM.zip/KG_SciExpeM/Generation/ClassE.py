# Dim Embedding
# path_case = './Scenario/CaseE'
#
# print('Sto Eseguendo -->', path_case)
# split_and_generate_dataset(path_scenario='./Scenario/CaseD')
#
# for index, d in enumerate([32, 64, 128, 256, 512]):
#     train(path_scenario=path_case, num=5, offset_x1=str(index), model_kwargs={'embedding_dim': d})
#     start_evaluate(path_scenario=path_case)

# Da metter in pipeline dal case D si va un mini search sulla dimensione dell'embedding