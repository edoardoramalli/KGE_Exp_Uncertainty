from Toy.BaseClasses import Experiment
import random
import os
import pandas as pd
import numpy as np
# Aggiungiamo alla media correlazione il similar

list_n_uncert = range(11, 22, 2)
list_diff = np.arange(0, 0.6, 0.1)


for c_un in list_n_uncert:
    for c_diff in list_diff:
        c_un = round(c_un, 4)
        c_diff = round(c_diff, 4)
        print('Test IN: {} - DIFF: {}'.format(c_un, c_diff))

        class C_Experiment(Experiment):
            list_similarities = [round(x, 3) for x in np.linspace(0, 1, c_un)]

            default_diff = c_diff

            def pick_uncertainty(self):
                diff = self.default_diff
                p_min, p_max = max(0, self.similarity - diff), min(1, self.similarity + diff)
                possibilities = [x for x in C_Experiment.list_similarities if p_min <= x <= p_max]
                return random.choice(possibilities)


        scenario = 'CaseF_{}_{}'.format(c_un, c_diff)

        general_path = '../Scenario/{}/Dataset/'.format(scenario)

        os.makedirs(general_path, exist_ok=True)

        csv = []

        exps = []

        list_of_records = []

        for i in range(1000):
            t = C_Experiment(i)
            exps.append(t)
            list_of_records.append(t.to_record())
            csv += t.to_kg()


        # for e in exps:
        #     c_u = e.uncertainty
        #     for ee in exps:
        #         # Now stesso autore quindi incertazza gia nelle possibili incertezze
        #         if e.similar(ee):
        #             e.close.add(ee.exp_id)
        #
        #     list_of_records.append(e.to_record())
        #     csv += e.to_kg()


        df = pd.DataFrame(list_of_records)

        df.to_csv(os.path.join(general_path, '{}_df.csv'.format(scenario)), index=False)

        with open(os.path.join(general_path, '{}.tsv'.format(scenario)), 'w+') as f:
            for i in csv:
                f.write(i + '\n')