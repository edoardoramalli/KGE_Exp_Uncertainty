from Toy.BaseClasses import Experiment
import random
import os
import pandas as pd

# Nessuna correlazione, baseline dati N metadati, l'incertezza o valore di un metadatp è random!


class C_Experiment(Experiment):

    def pick_uncertainty(self):
        return random.choice(Experiment.list_uncertainties)


scenario = 'CaseA'

general_path = '../Scenario/{}/Dataset/'.format(scenario)

os.makedirs(general_path, exist_ok=True)

csv = []

exps = []

list_of_records = []

# Case 8
for i in range(1000):
    t = C_Experiment(i)
    exps.append(t)
    list_of_records.append(t.to_record())
    csv += t.to_kg()

# for e in exps:
#     c_u = e.uncertainty
#     for ee in exps:
#         # Now stesso autore quindi incertazza gia nelle possibili incertezze
#         if e.similar(ee):
#             e.close.add(ee.exp_id)
#
#     list_of_records.append(e.to_record())
#     csv += e.to_kg()

df = pd.DataFrame(list_of_records)

df.to_csv(os.path.join(general_path, '{}_df.csv'.format(scenario)), index=False)

with open(os.path.join(general_path, '{}.tsv'.format(scenario)), 'w+') as f:
    for i in csv:
        f.write(i + '\n')
