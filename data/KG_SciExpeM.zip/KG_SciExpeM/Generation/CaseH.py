from Toy.BaseClasses import Experiment
import random
import os
import pandas as pd
import numpy as np
# Aggiungiamo alla media correlazione il similar

list_n_uncert = range(11, 22, 2)
list_diff = np.arange(0, 0.6, 0.1)


for c_un in list_n_uncert:
    for c_dip in range(0, 5, 1):
        c_un = round(c_un, 4)
        print('Test IN: {} - DIP: {}'.format(c_un, c_dip))

        class C_Experiment(Experiment):
            list_uncertainties = [round(x, 3) for x in np.linspace(0, 1, c_un)]

            n_dip = c_dip

            authors_activity = {}
            possible_uncertainty_author = {}
            possible_uncertainty_author_year = {}
            possible_uncertainty_author_year_exp_type = {}
            possible_uncertainty_author_year_exp_type_target = {}

            for i in range(Experiment.n_possible_author):
                c_author = f'Author {i}'
                authors_activity[c_author] = random.choice(Experiment.possible_year_of_activity)

                # index = list_uncertainties.index(random.choice(list_uncertainties))
                #
                # possible = list_uncertainties[max(0, index - 1): min(len(list_uncertainties), index + 2)]
                #
                possible_uncertainty_author[c_author] = random.choice(list_uncertainties)

                possible_uncertainty_author_year[c_author] = {}
                possible_uncertainty_author_year_exp_type[c_author] = {}
                possible_uncertainty_author_year_exp_type_target[c_author] = {}

                for year in range(authors_activity[c_author][0], authors_activity[c_author][1] + 1, 1):
                    possible_uncertainty_author_year[c_author][year] = random.choice(list_uncertainties)
                    possible_uncertainty_author_year_exp_type[c_author][year] = {}
                    possible_uncertainty_author_year_exp_type_target[c_author][year] = {}

                    for e_type in Experiment.possible_experiment_types:
                        possible_uncertainty_author_year_exp_type[c_author][year][e_type] = random.choice(
                            list_uncertainties)
                        possible_uncertainty_author_year_exp_type_target[c_author][year][e_type] = {}

                        for target in Experiment.possible_target:
                            possible_uncertainty_author_year_exp_type_target[c_author][year][e_type][
                                target] = random.choice(list_uncertainties)

            def pick_uncertainty(self):
                if c_dip == 0:
                    return random.choice(C_Experiment.list_uncertainties)
                elif c_dip == 1:
                    return C_Experiment.possible_uncertainty_author[self.author]
                elif c_dip == 2:
                    return C_Experiment.possible_uncertainty_author_year[self.author][self.year]
                elif c_dip == 3:
                    return C_Experiment.possible_uncertainty_author_year_exp_type[self.author][self.year][self.experiment_type]
                elif c_dip == 4:
                    return C_Experiment.possible_uncertainty_author_year_exp_type_target[self.author][self.year][
                        self.experiment_type][self.target]
                else:
                    raise ValueError()



        scenario = 'CaseH_{}_{}'.format(c_un, c_dip)

        general_path = '../Scenario/{}/Dataset/'.format(scenario)

        os.makedirs(general_path, exist_ok=True)

        csv = []

        exps = []

        list_of_records = []

        for i in range(50000):
            t = C_Experiment(i)
            exps.append(t)
            list_of_records.append(t.to_record())
            csv += t.to_kg()


        # for e in exps:
        #     c_u = e.uncertainty
        #     for ee in exps:
        #         # Now stesso autore quindi incertazza gia nelle possibili incertezze
        #         if e.similar(ee):
        #             e.close.add(ee.exp_id)
        #
        #     list_of_records.append(e.to_record())
        #     csv += e.to_kg()


        df = pd.DataFrame(list_of_records)

        df.to_csv(os.path.join(general_path, '{}_df.csv'.format(scenario)), index=False)

        with open(os.path.join(general_path, '{}.tsv'.format(scenario)), 'w+') as f:
            for i in csv:
                f.write(i + '\n')