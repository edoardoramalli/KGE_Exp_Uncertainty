from Toy.BaseClasses import Experiment
import random
import os
import pandas as pd

# Aggiungiamo media correlazione simile caso B

class C_Experiment(Experiment):

    def pick_uncertainty(self):
        v = round(self.similarity - random.choice([0, -0.1, -0.2, 0.1, 0.2, -0.3, 0.3, -0.4, 0.4]), 1)
        return v if 0 < v < 1 else 0 if v < 0 else 1


scenario = 'CaseC'

general_path = '../Scenario/{}/Dataset/'.format(scenario)

os.makedirs(general_path, exist_ok=True)

csv = []

exps = []

list_of_records = []

# Case 8
for i in range(1000):
    t = C_Experiment(i)
    exps.append(t)
    list_of_records.append(t.to_record())
    csv += t.to_kg()

df = pd.DataFrame(list_of_records)

df.to_csv(os.path.join(general_path, '{}_df.csv'.format(scenario)), index=False)

with open(os.path.join(general_path, '{}.tsv'.format(scenario)), 'w+') as f:
    for i in csv:
        f.write(i + '\n')