import random
import pandas as pd
import os
import numpy as np


class Triple:

    def __init__(self, head, relation, tail):
        self.head = str(head)
        self.relation = str(relation)
        self.tail = str(tail)

    def to_string(self, sep='\t', order=('head', 'relation', 'tail')):
        txt = ''
        for i in order:
            txt += self.__dict__[i] + sep
        return txt[:-1]


class Experiment:
    possible_experiment_types = {
        'ignition delay measurement': ['shock tube', 'rapid compression machine'],
        'laminar burning velocity measurement': ['flame'],
        'outlet concentration measurement': ['shock tube', 'stirred reactor', 'flow reactor'],
        'concentration time profile measurement': ['shock tube', 'stirred reactor', 'flow reactor'],
        'jet stirred reactor measurement': ['shock tube', 'stirred reactor', 'flow reactor'],
        'burner stabilized flame speciation measurement': ['flame'], }

    possible_year_of_activity = [(i, i + 10) for i in range(1950, 2030, 10)]

    list_uncertainties = [round(x, 3) for x in np.linspace(0, 1, 11)]
    list_similarities = [round(x, 3) for x in np.linspace(0, 1, 11)]
    possible_target = ['H2', 'IDT', 'C0', 'H20', 'CO2', 'NH3', 'CH4', 'CH3', 'C5H6', 'C6H6', 'H2S', 'C7H8']
    n_possible_author = 50

    authors_activity = {}
    possible_uncertainty_author = {}
    possible_uncertainty_author_year = {}
    possible_uncertainty_author_year_exp_type = {}
    possible_uncertainty_author_year_exp_type_target = {}

    for i in range(n_possible_author):
        c_author = f'Author {i}'
        authors_activity[c_author] = random.choice(possible_year_of_activity)


    def pick_reactor(self):
        return random.choice(self.possible_experiment_types[self.experiment_type])

    def pick_experiment_type(self):
        exp_type = random.choice(list(self.possible_experiment_types.keys()))
        return exp_type

    def pick_author(self):
        return random.choice(list(self.authors_activity.keys()))

    def pick_year(self):
        active_years = self.authors_activity[self.author]
        return random.randint(active_years[0], active_years[1])

    def pick_target(self):
        return random.choice(self.possible_target)

    def pick_similarity(self):
        return random.choice(self.list_similarities)

    def pick_uncertainty(self):
        return
        # if self.similarity > 0.9:
        #     return random.choice([0.9, 1])
        # return random.choice([0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1])

        # Case 0
        # return round(random.random(), 1)

        # Case 1
        # return round(1 - self.similarity, 1)

        # Case 2
        # u = round(1 - self.similarity, 1)
        #
        # e = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        #
        # i = e.index(u)
        #
        # possible = e[max(0, i - 1): min(len(e), i + 2)]
        #
        # return random.choice(possible)

        # # Case 3
        # u = round(1 - self.similarity, 1)
        #
        # e = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        #
        # i = e.index(u)
        #
        # possible = e[max(0, i - 2): min(len(e), i + 3)]
        #
        # return random.choice(possible)

        # Case 4
        # u = round(1 - self.similarity, 1)
        #
        # e = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
        #
        # i = e.index(u)
        #
        # possible = e[max(0, i - 3): min(len(e), i + 4)]
        #
        # return random.choice(possible)

        # # Case 5
        # return round(random.random(), 1)

        # # Case 6
        # inf, sup = self.possible_uncertainty_author[self.author]
        # return round(random.uniform(inf, sup), 1)

    def meta_similar(self, other_exp):
        if self.experiment_type == other_exp.experiment_type:
            if self.reactor == other_exp.reactor:
                if self.target == other_exp.target:
                    return True
                    # Case8
                    # if self.author == other_exp.author:
                    #     return True
        return False

    def similar(self, other_exp):
        if self.meta_similar(other_exp):
            if abs(self.similarity - other_exp.similarity) <= 0.15:
                return True
        return False

    def __init__(self, exp_id):
        self.exp_id = 'ID:' + str(exp_id)
        self.experiment_type = self.pick_experiment_type()
        self.reactor = self.pick_reactor()
        self.author = self.pick_author()
        self.year = self.pick_year()
        self.target = self.pick_target()
        self.similarity = self.pick_similarity()
        self.uncertainty = self.pick_uncertainty()

        self.close = set([])

    def __repr__(self):
        return f'<{self.exp_id}->{self.experiment_type[:8]}|{self.reactor}|{self.author}|{self.year}|{self.target}|{self.similarity}|{self.uncertainty}>'

    def to_kg(self, sep='\t', order=('head', 'relation', 'tail')):
        list_of_triples = []
        list_of_triples.append(
            Triple(self.exp_id, 'of_type', 'TY_' + self.experiment_type).to_string(sep=sep, order=order))
        list_of_triples.append(Triple(self.exp_id, 'of_reactor', 'R_' + self.reactor).to_string(sep=sep, order=order))
        list_of_triples.append(Triple(self.exp_id, 'has_author', self.author).to_string(sep=sep, order=order))
        list_of_triples.append(Triple(self.exp_id, 'of_year', 'Y_' + str(self.year)).to_string(sep=sep, order=order))
        list_of_triples.append(Triple(self.exp_id, 'of_target', 'T_' + self.target).to_string(sep=sep, order=order))
        list_of_triples.append(
            Triple(self.exp_id, 'has_similarity', 'S_' + str(self.similarity)).to_string(sep=sep, order=order))
        list_of_triples.append(
            Triple(self.exp_id, 'has_uncertainty', 'U_' + str(self.uncertainty)).to_string(sep=sep, order=order))

        for close in self.close:
            list_of_triples.append(Triple(self.exp_id, 'is_close', close).to_string(sep=sep, order=order))

        return list_of_triples

    def to_record(self):
        return {
            'experiment_type': self.experiment_type,
            'reactor': self.reactor,
            'author': self.author,
            'year': self.year,
            'target': self.target,
            'similarity': self.similarity,
            'uncertainty': self.uncertainty
        }


# scenario = 'Case8'
#
# general_path = './Scenario/{}/Dataset/'.format(scenario)
#
# os.makedirs(general_path, exist_ok=True)
#
# csv = []
#
# exps = []
#
# list_of_records = []

# for i in range(1000):
#     t = Experiment(i)
#     exps.append(t)
#     list_of_records.append(t.to_record())
#     csv += t.to_kg()


# # Case 5
# for i in range(1000):
#     t = Experiment(i)
#     exps.append(t)
#
# for e in exps:
#     c_u = e.uncertainty
#     for ee in exps:
#         if e.similar(ee):
#             ee.uncertainty = c_u
#             e.close.add(ee.exp_id)
#
#     list_of_records.append(e.to_record())
#     csv += e.to_kg()


# # Case 8
# for i in range(1000):
#     t = Experiment(i)
#     exps.append(t)
#
# for e in exps:
#     c_u = e.uncertainty
#     for ee in exps:
#         # Now stesso autore quindi incertazza gia nelle possibili incertezze
#         if e.similar(ee):
#             e.close.add(ee.exp_id)
#
#     list_of_records.append(e.to_record())
#     csv += e.to_kg()
#
#
#
#
# df = pd.DataFrame(list_of_records)
# df.to_csv(os.path.join(general_path, '{}_df.csv'.format(scenario)), index=False)
#
#
# with open(os.path.join(general_path, '{}.tsv'.format(scenario)), 'w+') as f:
#     for i in csv:
#         f.write(i + '\n')