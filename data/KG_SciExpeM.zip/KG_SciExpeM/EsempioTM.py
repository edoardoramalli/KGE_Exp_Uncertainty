import pandas as pd
from random import randint


def generate_random_data(inf, sup, n=10):
    return [randint(inf, sup) for _ in range(n)]

my_diz = {
    'names': ['A', 'B', 'C', 'D', 'E'],
    'age': generate_random_data(20, 30, 5),
    'salary': generate_random_data(1000, 2000),
}

df = pd.DataFrame(my_diz)

a = sum(df['salary']) / len(my_diz['names'])


for index, row in df.iterrows():
    if row['salary'] > a:
        df.loc[index, 'wealthy'] = True
    else:
        df.loc[index, 'wealthy'] = False



# 1. In the code there is an error. Identify it, explain why it is an error and provide a simple solution without changing the program logic.
#
# 2. Provide a qualitative description step by step, in simple terms, of the program workflow, pretending there is no error or the error has been adequately corrected
#
# 3. Exaplain the difference between the 'continue' and 'break' statements in python.














exit()







# # workflow
# # 2 errors
# # continue and break

import random
import pandas as pan


def analyze_list(A):
    def my_len(A):
        k = 0
        for _ in A:
            k += 1
        return k

    tmp = 0

    for i in range(my_len(A)):
        tmp += A[i]
    return tmp / my_len(A)

my_list = ['a', 'b', 'c', 'd']

my_diz = {l: [random.randint(0, 10) for _ in range(10)] for l in my_list}

df = pan.DataFrame(my_diz)

df = df[df['a'] + df['b'] + df['c'] > df['d']]

j = 0

final = []

while j < len(df):
    z = 0
    for i in range(len(list(df.columns))):
        z += df.iloc[j, i]
    j += 1
    final.append(z)

print(analyze_list(final))


