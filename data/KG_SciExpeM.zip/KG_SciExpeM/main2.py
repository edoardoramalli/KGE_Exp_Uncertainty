from pykeen.datasets import Countries
from pykeen.pipeline import pipeline
from pykeen.models import TransE
from pykeen.models import predict
import torch
from pykeen.datasets import get_dataset

import matplotlib.pyplot as plt



pipeline_result = pipeline(
     dataset=Countries,
     model=TransE,
     epochs=500,)

pipeline_result.plot()

plt.show()

pipeline_result.plot_er()

plt.show()

pipeline_result.plot_losses()

plt.show()

