import statistics
import json
import glob
import os

def hits(ll, k=10):
    return len(list(filter(lambda x: x <= k, ll))) / len(ll)

def var(f, i):
    return str(f) + '\t' + str(int((f - i) / i * 100)) + '%'

# H_30 = round(hits(result, k=15), 3)
# H_25 = round(hits(result, k=15), 3)
# H_20 = round(hits(result, k=15), 3)
# H_15 = round(hits(result, k=15), 3)
# H_10 = round(hits(result, k=15), 3)
# H_5 = round(hits(result, k=15), 3)
# H_4 = round(hits(result, k=15), 3)
# H_3 = round(hits(result, k=15), 3)
# H_2 = round(hits(result, k=15), 3)
# H_1 = round(hits(result, k=15), 3)


H_LIST = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 20, 25, 30, 35, 50]

# path_case = './Scenario/CaseA'

def aggregate(path_case):

    json_paths = glob.glob(os.path.join(path_case, './**/evaluation_results.json'))

    rr = {'H': {}, 'D': {}}

    for json_file in json_paths:
        with open(json_file, 'r') as f:
            diz = json.load(f)

        result = diz['R']
        diffs = diz['D']
        u = diz['U']

        for h in H_LIST:
            c_r = round(hits(result, k=h), 3)
            rr['H'][h] = rr['H'].get(h, []) + [c_r]
            # print('H@{}: {}'.format(h, ))

        # print('H@30:', H_30)
        # print('H@25:', var(round(hits(result, k=15), 3), 0.896))
        # print('H@20:', var(round(hits(result, k=15), 3), 0.896))
        # print('H@15:', var(round(hits(result, k=15), 3), 0.896))
        # print('H@10:', var(round(hits(result, k=10), 3), 0.896))
        # print('H@5: ', var(round(hits(result, k=5), 3), 0.358))
        # print('H@3: ', var(round(hits(result, k=3), 3), 0.189))
        # print('H@2: ', var(round(hits(result, k=2), 3), 0.142))
        # print('H@1: ', var(round(hits(result, k=1), 3), 0.075))

        # t_diffs = [abs(d) for d in diffs if d != 0.0]

        t_diffs = [abs(d) for d in diffs]

        # print(t_diffs)

        avg = round(statistics.mean(t_diffs), 2)
        median = round(statistics.median(t_diffs), 2)
        stdev = round(statistics.stdev(t_diffs), 2)
        var = round(statistics.variance(t_diffs), 2)
        mmin = round(min(t_diffs), 2)
        mmax = round(max(t_diffs), 2)

        rr['D']['avg'] = rr['D'].get('avg', []) + [avg]
        rr['D']['median'] = rr['D'].get('median', []) + [avg]
        rr['D']['stdev'] = rr['D'].get('stdev', []) + [avg]
        rr['D']['var'] = rr['D'].get('var', []) + [var]
        rr['D']['mmin'] = rr['D'].get('mmin', []) + [mmin]
        rr['D']['mmax'] = rr['D'].get('mmax', []) + [mmax]

        # print('Diff Error ({}) -> '.format(len(t_diffs)), )
        # print('\t', 'Avg:', avg)
        # print('\t', 'Median:', median, )
        # print('\t', 'Stdev:', stdev, )
        # print('\t', 'Var:', var, )
        # print('\t', 'Min:', mmin, )
        # print('\t', 'Max:', mmax)

    return rr if rr['H'] != {} else None

    # print(rr)
