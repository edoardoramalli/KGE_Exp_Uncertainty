from pykeen.pipeline import pipeline
from pykeen.triples import TriplesFactory
import os


def train(path_scenario, num=1, offset_x1=None, offset_x2=None, **kwargs):
    training = TriplesFactory.from_path_binary(os.path.join(path_scenario, 'Dataset', 'training'))
    testing = TriplesFactory.from_path_binary(os.path.join(path_scenario, 'Dataset', 'testing'))
    validation = TriplesFactory.from_path_binary(os.path.join(path_scenario, 'Dataset', 'validation'))

    for i in range(num):
        print('Training {} / {}'.format(i + 1, num))

        diz_default = dict(
            training=training,
            testing=testing,
            validation=validation,
            model='RotatE',
            model_kwargs=dict(embedding_dim=64),
            training_loop='slcwa',
            training_kwargs=dict(num_epochs=15000, batch_size=2048 * 4),
            use_tqdm=True,
            stopper='early',
            stopper_kwargs=dict(frequency=500, patience=3, relative_delta=0.005, metric="hits@3", ),
        )

        setting = {**diz_default, **kwargs}

        result = pipeline(**setting)


        if offset_x1 and offset_x2:
            file_name = 'results.{}.{}_{}'.format(offset_x1, offset_x2, i)
        elif offset_x1:
            file_name = 'results.{}_{}'.format(offset_x1, i)
        else:
            file_name = 'results_{}'.format(i)

        result.save_to_directory(os.path.join(path_scenario, file_name))
