import os


scenario = 'CaseD_Bis'
general_path = './Scenario/{}/Dataset/'.format(scenario)

path = os.path.join(general_path, f'{scenario}.tsv')
df_path = os.path.join(general_path, f'{scenario}_df.csv')

entities = {}

rules = [
    {'entity': 'experiment', 'rule': 'ID:'},
    {'entity': 'type', 'rule': 'TY_'},
    {'entity': 'reactor', 'rule': 'R_'},
    {'entity': 'author', 'rule': 'Author'},
    {'entity': 'year', 'rule': 'Y_'},
    {'entity': 'target', 'rule': 'T_'},
    {'entity': 'similarity', 'rule': 'S_'},
    {'entity': 'uncertainty', 'rule': 'U_'},
]


def check_entity(entity, list_rules):
    for rule in list_rules:
        if entity.startswith(rule['rule']):
            return rule['entity']
    raise ValueError('No entity found for: ' + entity)



relations = {}

triples_count = 0

with open(path, 'r') as f:
    for line in f:
        triples_count += 1

        split_line = line.split('\t')

        h = split_line[0].strip()
        r = split_line[1].strip()
        t = split_line[2].strip()

        type_h = check_entity(h, rules)
        type_t = check_entity(t, rules)

        entities[type_h] = entities.get(type_h, []) + [h]
        entities[type_t] = entities.get(type_t, []) + [t]

        relations[r] = relations.get(r, 0) + 1

print('Triples: ' + str(triples_count))
print('Entities ({}):'.format(len(entities)))
for entity in entities:
    print('\t', entity, ': ', len(set(entities[entity])))
    if entity == 'uncertainty':
        print(set(entities[entity]))
print('Relations ({}):'.format(len(relations)))
for relation in relations:
    print('\t', relation, ': ', relations[relation])


import pandas as pd
from scipy import stats

import numpy as np
import itertools
from scipy.stats import pearsonr, pointbiserialr, chi2_contingency
import seaborn as sns
import matplotlib.pyplot as plt

def from_cat_to_int(list_cat, reset=0):
    list_int = {}
    index = reset
    result = []
    for e in list_cat:
        if e in list_int:
            result.append(list_int[e])
        else:
            list_int[e] = index
            index += 1
            result.append(list_int[e])
    return result


df = pd.read_csv(df_path)

df = df.rename(columns={'author': 'Author',
                   'experiment_type': 'Experiment Type',
           'reactor': 'Reactor',
           'similarity': 'Similarity',
           'target': 'Target',
       'uncertainty': 'Uncertainty',
           'year': 'Year'})

cat_cols = set(df.select_dtypes(include=[object]).columns)
num_cols = set(df.columns) - cat_cols


cols = {col: 'cat' for col in cat_cols}
cols = {**cols, **{col: 'num' for col in num_cols}}

edo = pd.DataFrame(columns=sorted(cols.keys()), index=sorted(cols.keys()))



# print(edo.columns)


for pair in itertools.combinations(cols.keys(), 2):
    x = pair[0]
    y = pair[1]

    if cols[x] == 'cat' and cols[y] == 'cat':
        data = np.array([from_cat_to_int(df[x]), from_cat_to_int(df[y], reset=len(df[x]))])
        X2 = chi2_contingency(data, correction=False)[0]
        n = np.sum(data)
        minDim = min(data.shape) - 1
        c, p = np.sqrt((X2/n) / minDim), 0
    elif cols[x] == 'num' and cols[y] == 'num':
        c, p = pearsonr(df[x], df[y])
    elif cols[x] == 'cat' and cols[y] == 'num':
        c, p = pointbiserialr(from_cat_to_int(df[x]), df[y])
    elif cols[x] == 'num' and cols[y] == 'cat':
        c, p = pointbiserialr(from_cat_to_int(df[y]), df[x])

    edo.loc[x, y] = c
    edo.loc[y, x] = c

np.fill_diagonal(edo.values, 1)

# Generate a mask for the upper triangle
mask = np.triu(np.ones_like(edo, dtype=bool))

# Set up the matplotlib figure
f, ax = plt.subplots(figsize=(11, 9))

# Generate a custom diverging colormap
cmap = sns.diverging_palette(230, 20, as_cmap=True)

edo = edo.astype(dtype='float64')

# Draw the heatmap with the mask and correct aspect ratio
sns.heatmap(edo, mask=mask, cmap=cmap, vmax=1, vmin=-1, center=0, square=True, linewidths=.5, cbar_kws={"shrink": .5}, annot=True, annot_kws={"size": 18})



plt.savefig('/Users/edoardo/Desktop/{}_Corr.pdf'.format(scenario), bbox_inches='tight')

plt.show()