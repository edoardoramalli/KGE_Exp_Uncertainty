from Training import train
from Evaluate import start_evaluate
from generateDataSets import split_and_generate_dataset

import glob
from tqdm import tqdm

# path_case = './Scenario/CaseD_Bis'

# paths = glob.glob('./Scenario/CaseH_*')


paths = glob.glob('./Scenario/CaseI_21_*')

for test in tqdm(paths):
    print('Sto Eseguendo -->', test)
    split_and_generate_dataset(path_scenario=test)
    train(path_scenario=test, num=3)
    start_evaluate(path_scenario=test)

# path_case = './Scenario/CaseC'
#
# split_and_generate_dataset(path_scenario=path_case)
# train(path_scenario=path_case, num=5)
# start_evaluate(path_scenario=path_case)


# Dim Embedding
# path_case = './Scenario/CaseA'
#
# print('Sto Eseguendo -->', path_case)
# split_and_generate_dataset(path_scenario=path_case)
#
# for index, d in enumerate([16, 32, 64, 128, 256, 512]):
#     train(path_scenario=path_case, num=3, offset_x1=str(index), model_kwargs={'embedding_dim': d})
#     start_evaluate(path_scenario=path_case)