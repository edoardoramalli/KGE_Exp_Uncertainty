from pykeen.triples import TriplesFactory
from pykeen.pipeline import pipeline
from pykeen.evaluation import RankBasedEvaluator
from pykeen.models import TransE
import torch


scenario = 'case_1'




# a = pipeline().plot()

tf = TriplesFactory.from_path(f'{scenario}.tsv')

training, testing, validation = tf.split([.8, .1, .1])

training.to_path_binary(path=f'{scenario}__training')
testing.to_path_binary(path=f'{scenario}__testing')
validation.to_path_binary(path=f'{scenario}__validation')

# edo = TriplesFactory.from_path_binary('training.tsv')
#
#
# print(type(edo))

exit()

result = pipeline(
    training=training,
    testing=testing,
    # validation=validation,
    model='TransE',
    model_kwargs=dict(embedding_dim=128),
    # stopper='early',
    training_loop='slcwa',
    training_kwargs=dict(num_epochs=5, batch_size=1024),
    use_tqdm=True,
    # stopper_kwargs=dict(frequency=100, patience=3, relative_delta=0.002),
    evaluation_relation_whitelist={'has_uncertainty'}
)


result.save_to_directory('case_0')

# Define model
# model = TransE(
#     triples_factory=training,
# )

# Train your model (code is omitted for brevity)


# model = torch.load('case_0/trained_model.pkl')
#
# Define evaluator
# evaluator = RankBasedEvaluator(
#     filtered=True,  # Note: this is True by default; we're just being explicit
# )
#
# # Evaluate your model with not only testing triples,
# # but also filter on validation triples
# results = evaluator.evaluate(
#     model=model,
#     mapped_triples=testing.mapped_triples,
#     additional_filter_triples=[
#     training.mapped_triples,
#     validation.mapped_triples,
#     ],
# )
#
# print(results)
# print(results.to_dict())
