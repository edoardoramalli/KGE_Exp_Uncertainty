e = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]

f = 0.3



i = e.index(f)

edo = e[max(0, i-1): min(len(e), i+2)]

print(edo)



