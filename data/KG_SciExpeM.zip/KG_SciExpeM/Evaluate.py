from pykeen.evaluation import RankBasedEvaluator
from pykeen.evaluation import evaluate
from pykeen.triples import TriplesFactory
import torch
from pykeen.models import predict
import os
import statistics
import json
import glob
import os

PYTHON_DEVICE = os.environ['PYTHON_DEVICE']



# u = ['U_' + str(i) for i in [0, 0.0, 0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1, 1.0]] + ['U_None']


def evaluate_result(current_path, training_object, testing_object):

    u = [e for e in training_object.entity_labeling.label_to_id if e.startswith('U')]

    model = torch.load(os.path.join(current_path, 'trained_model.pkl'), map_location=torch.device(PYTHON_DEVICE))

    result = []

    diffs = []

    for triple in testing_object.triples:
        if triple[1] != 'has_uncertainty':
            continue

        predicted_tails_df = predict.get_tail_prediction_df(model, triple[0], 'has_uncertainty', triples_factory=training_object, )

        predicted_tails_df = predicted_tails_df[predicted_tails_df['tail_label'].isin(u)]

        predicted_tails_df = predicted_tails_df.reset_index()

        rank = predicted_tails_df[predicted_tails_df['tail_label'] == triple[2]].index.values.astype(int)[0]

        diff = float(predicted_tails_df.iloc[0]['tail_label'][2:]) - float(predicted_tails_df.iloc[rank]['tail_label'][2:])

        diffs.append(float(diff))

        result.append(int(rank + 1))


    diz = {'U': u, 'R': result, 'D': diffs}

    with open(os.path.join(current_path, 'evaluation_results.json'), 'w+') as f:

        print(current_path)
        json.dump(diz, f, indent=4)


def start_evaluate(path_scenario):
    # scenario = 'Case1'
    # general_path = './Scenario/{}/Dataset/'.format(scenario)

    training = TriplesFactory.from_path_binary(os.path.join(path_scenario, 'Dataset', 'training'))
    testing = TriplesFactory.from_path_binary(os.path.join(path_scenario, 'Dataset', 'testing'))
    validation = TriplesFactory.from_path_binary(os.path.join(path_scenario, 'Dataset', 'validation'))

    paths = glob.glob(os.path.join(path_scenario, './**/*.pkl'))

    for index, test in enumerate(paths):
        print('Start Evaluate {}/{}'.format(index + 1, len(paths)))
        parent_test_folder = os.path.dirname(test)
        evaluate_result(current_path=parent_test_folder, training_object=training, testing_object=testing)

