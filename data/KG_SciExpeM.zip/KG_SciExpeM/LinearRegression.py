import pandas as pd
from sklearn import linear_model
import os
from sklearn.model_selection import train_test_split
from statistics import mean




file_df = './Scenario/CaseG_21_4/Dataset/CaseG_21_4_df.csv'


def compute_regression(path):

    df = pd.read_csv(path)


    cols = ['experiment_type', 'reactor', 'author', 'year', 'target', 'similarity', 'uncertainty']

    regr = linear_model.LinearRegression()

    X = df[['experiment_type', 'reactor', 'author', 'year', 'target', 'similarity']]
    X = pd.get_dummies(data=X, drop_first=True)
    Y = df['uncertainty']

    rr = []

    for _ in range(10):
        X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size = .20)
        X_test, X_trash, Y_test, Y_trash = train_test_split(X_test, Y_test, test_size = .50)

        regr.fit(X_train, Y_train)

        predictions = regr.predict(X_test)


        # print(Y_test)

        Y_test = list(Y_test)

        rr.append(mean([abs(predictions[index]-Y_test[index]) for index in range(len(X_test))]))

    return mean(rr)

# print(predictions)